package com.capg.moviemgmt.exception;

public class ScreenNotFoundException extends RuntimeException {

	public ScreenNotFoundException(String message) {
		super(message);
	}

}