package com.capg.moviemgmt.exception;

public class MovieNotFoundException extends RuntimeException {

	public MovieNotFoundException(String str) {
		
		super(str) ;
	}
	
}
