package com.capg.moviemgmt.service;

import java.util.List;

import com.capg.moviemgmt.entities.Show;


public interface IShowService {

	Show Save(Show s) ;
	Show fetchById(int showId) ;
	String DeleteShow(int showId);
	List<Show>fetchAll() ; 
	
	
	
}
