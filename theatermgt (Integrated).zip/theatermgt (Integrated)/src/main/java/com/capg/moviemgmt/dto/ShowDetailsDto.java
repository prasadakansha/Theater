package com.capg.moviemgmt.dto;

import java.time.LocalDateTime;
import java.util.List;

import com.capg.moviemgmt.entities.Seat;
public class ShowDetailsDto {

	private int showId;
	private String showName;
	private LocalDateTime starttime ;
	private LocalDateTime endtime  ;
	private String movieName ;
	private List<Seat>seatsId;
	
	public int getShowId() {
		return showId;
	}
	public void setShowId(int showId) {
		this.showId = showId;
	}
	public String getShowName() {
		return showName;
	}
	public void setShowName(String showName) {
		this.showName = showName;
	}
	public LocalDateTime getStarttime() {
		return starttime;
	}
	public void setStarttime(LocalDateTime starttime) {
		this.starttime = starttime;
	}
	public LocalDateTime getEndtime() {
		return endtime;
	}
	public void setEndtime(LocalDateTime endtime) {
		this.endtime = endtime;
	}

	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public List<Seat> getSeatsId() {
		return seatsId;
	}
	public void setSeatsId(List<Seat> seatsId) {
		this.seatsId = seatsId;
	}

  

}
