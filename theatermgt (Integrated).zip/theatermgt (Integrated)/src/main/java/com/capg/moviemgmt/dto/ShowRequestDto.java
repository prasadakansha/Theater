package com.capg.moviemgmt.dto;

import java.time.LocalDateTime;
import java.util.List;

import com.capg.moviemgmt.entities.Seat;

public class ShowRequestDto {
	
	
	private String showName;
	private LocalDateTime showStartTime ;
	private LocalDateTime showEndTime  ;
	private String movieName ;
	private List<Seat>seatsId;
	public String getShowName() {
		return showName;
	}
	public void setShowName(String showName) {
		this.showName = showName;
	}
	public LocalDateTime getShowStartTime() {
		return showStartTime;
	}
	public void setShowStartTime(LocalDateTime showStartTime) {
		this.showStartTime = showStartTime;
	}
	public LocalDateTime getShowEndTime() {
		return showEndTime;
	}
	public void setShowEndTime(LocalDateTime showEndTime) {
		this.showEndTime = showEndTime;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public List<Seat> getSeatsId() {
		return seatsId;
	}
	public void setSeatsId(List<Seat> seatsId) {
		this.seatsId = seatsId;
	}
	
	
}