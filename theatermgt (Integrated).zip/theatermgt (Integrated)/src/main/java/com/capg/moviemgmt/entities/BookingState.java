package com.capg.moviemgmt.entities;

public enum BookingState {
	
	Available, Booked, Blocked

}
