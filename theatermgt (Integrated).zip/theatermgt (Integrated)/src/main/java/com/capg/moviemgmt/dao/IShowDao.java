package com.capg.moviemgmt.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capg.moviemgmt.entities.Show;



public interface IShowDao extends JpaRepository<Show, Integer> {

}
